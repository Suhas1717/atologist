export interface IUser {
  "firstName": string
  "lastName": string
  "email": string
  "mobile": number | string
  "password": string
  "date_of_birth": string
  "terms": boolean
  "privacy": boolean
}
